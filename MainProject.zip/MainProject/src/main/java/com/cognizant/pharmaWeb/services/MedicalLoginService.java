package com.cognizant.pharmaWeb.services;

import com.cognizant.pharmaWeb.entities.MedicalLogin;

public interface MedicalLoginService {

	MedicalLogin saveMedicalLogin(MedicalLogin medicalLogin);
}
